package com.fizzbuzz;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.fizzbuzz.service.FizzBuzzSerivce;

public class FizzBuzzTest {

	@Test
	public void testGetFizzBuzzList() {
		FizzBuzzSerivce service = new FizzBuzzSerivce();
		List<String> actualResult = service.getFizzBuzzList(0, 20);
		List<String> expectedList = Arrays.asList("fizzbuzz", "1", "2", "fizz", "4", "buzz", "fizz", "7", "8", "fizz",
				"buzz", "11", "fizz", "13", "14", "fizzbuzz", "16", "17", "fizz", "19","buzz");
		assertArrayEquals(expectedList.toArray(), actualResult.toArray());

	}

	@Test
	public void testGetFizzBuzzLuckyList() {
		FizzBuzzSerivce service = new FizzBuzzSerivce();
		List<String> actualResult = service.getFizzBuzzLuckyList(0, 20);
		List<String> expectedList = Arrays.asList("fizzbuzz", "1", "2", "Lucky", "4", "buzz", "fizz", "7", "8", "fizz",
				"buzz", "11", "fizz", "Lucky", "14", "fizzbuzz", "16", "17", "fizz", "19","buzz");
		assertArrayEquals(expectedList.toArray(), actualResult.toArray());
	}
	
	@Test
	public void testSingleElementRange() {
		FizzBuzzSerivce service = new FizzBuzzSerivce();
		List<String> actualResult = service.getFizzBuzzLuckyList(5, 5);
		List<String> expectedList = Arrays.asList("buzz");
		assertArrayEquals(expectedList.toArray(), actualResult.toArray());
	}

	@Test
	public void testGetFizzBuzzOccurence() {
		FizzBuzzSerivce service = new FizzBuzzSerivce();
		Map<String, Integer> expectedMap = new HashMap<String, Integer>();
		expectedMap.put("number", 10);
		expectedMap.put("fizz", 4);
		expectedMap.put("fizzbuzz", 2);
		expectedMap.put("buzz", 3);
		expectedMap.put("Lucky", 2);
		Map<String, Integer> actualResult = service.getFizzBuzzOccurence(0, 20);
		assertTrue(expectedMap.equals(actualResult));

	}

}
