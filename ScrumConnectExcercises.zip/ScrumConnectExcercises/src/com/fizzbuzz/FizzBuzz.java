package com.fizzbuzz;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.fizzbuzz.service.FizzBuzzSerivce;

public class FizzBuzz {

	public static void main(String[] args) {
		FizzBuzzSerivce service = new FizzBuzzSerivce();
		Scanner readData = new Scanner(System.in);
		try {
			System.out.println("Enter a range start");
			int rangeStarts = readData.nextInt();

			System.out.println("Enter a range ends");
			int rangeEnds = readData.nextInt();

			if (rangeEnds < rangeStarts) {
				throw new InputMismatchException("Invalid Range!!");
			}

			System.out.println(service.getFizzBuzzList(rangeStarts, rangeEnds));
			System.out.println(service.getFizzBuzzLuckyList(rangeStarts, rangeEnds));
			System.out.println(service.getFizzBuzzOccurence(rangeStarts, rangeEnds));

		} catch (InputMismatchException e) {
			if (e.getMessage() == null || e.getMessage().isEmpty()) {
				System.out.println("Invalid input format");
			} else {
				System.out.println(e.getMessage());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			readData.close();
		}

	}

}
