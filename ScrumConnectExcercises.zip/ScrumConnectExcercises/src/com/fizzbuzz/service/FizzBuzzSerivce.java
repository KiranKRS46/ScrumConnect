package com.fizzbuzz.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class FizzBuzzSerivce {

	public List<String> getFizzBuzzList(int rangeStarts, int rangeEnds) {

		IntStream integerStream = IntStream.range(rangeStarts, rangeEnds+1);
		List<Integer> intArray = integerStream.boxed().collect(Collectors.toList());
		Stream<Integer> stream = intArray.parallelStream();

		List<String> result = stream.map(num -> {
			String returnValue = null;
			if (num % 3 == 0 && num % 5 == 0) {
				returnValue = "fizzbuzz";
			} else if (num % 5 == 0) {
				returnValue = "buzz";
			} else if (num % 3 == 0) {
				returnValue = "fizz";
			} else {
				returnValue = Integer.toString(num);
			}
			return returnValue;
		}).collect(Collectors.toList());
		return result;
	}

	public List<String> getFizzBuzzLuckyList(int rangeStarts, int rangeEnds) {
		IntStream integerStream = IntStream.range(rangeStarts, rangeEnds+1);
		List<Integer> intArray = integerStream.boxed().collect(Collectors.toList());
		Stream<Integer> stream = intArray.parallelStream();

		List<String> result = stream.map(num -> {
			String returnValue = null;
			if (Integer.toString(num).contains("3")) {
				returnValue = "Lucky";
			} else if (num % 3 == 0 && num % 5 == 0) {
				returnValue = "fizzbuzz";
			} else if (num % 5 == 0) {
				returnValue = "buzz";
			} else if (num % 3 == 0) {
				returnValue = "fizz";
			} else {
				returnValue = Integer.toString(num);
			}
			return returnValue;
		}).collect(Collectors.toList());
		return result;

	}

	public Map<String, Integer> getFizzBuzzOccurence(int rangeStarts, int rangeEnds) {
		List<String> fizzBuzzList = this.getFizzBuzzLuckyList(rangeStarts, rangeEnds);
		Map<String, Integer> statistics = new HashMap<String, Integer>();
		statistics.put("fizz", (int) fizzBuzzList.stream().filter(str -> str.equals("fizz")).count());
		statistics.put("buzz", (int) fizzBuzzList.stream().filter(str -> str.equals("buzz")).count());
		statistics.put("Lucky", (int) fizzBuzzList.stream().filter(str -> str.equals("Lucky")).count());
		statistics.put("fizzbuzz", (int) fizzBuzzList.stream().filter(str -> str.equals("fizzbuzz")).count());
		statistics.put("number", (int) fizzBuzzList.stream().filter(str -> str.matches("\\d+")).count());
		return statistics;
	}

}
